---
name: android-phone-launcher
description: Build, customize, install and publish a custom Android PHONE home-screen launcher (Arabic/RTL friendly) from a tested template - drag-and-drop 4x6 grid with dock, app drawer with search, real Android widgets (AppWidgetHost), built-in clock + Hijri date + prayer-times widgets, time-of-day nature wallpapers, default-launcher request, signed APK and GitHub release. Use when the user asks to make, change, test or ship a launcher / home screen / واجهة / لانشر for an Android phone, or to install one on a phone over adb. Not for Android TV boxes (that is the TV launcher at D:\tv-dl\oussama-tv).
---

# Android phone launcher

A launcher is a normal Android app whose activity answers `MAIN` + `HOME`. This skill starts from a working
template (`template/` next to this file, Java, no third-party libraries, minSdk 26, ~2.5 MB) and adapts it to the
owner's wishes, then builds it, installs it on their phone over adb, checks it with real screenshots, and
optionally signs and publishes it.

Talk to the owner in their language (Arabic by default). Ask before any download, before installing anything on
their phone, and before publishing anything. Never type their passwords.

## 1. Ask what they want (one short round)

Use one checklist question round, defaults pre-selected:
- Phone brand / model and Android version (Settings > About phone). Xiaomi, Samsung, Huawei matter (see pitfalls).
- Layout: grid size (4x6 default), dock apps, which apps start on the home screen.
- Widgets: clock with Hijri date, prayer times (city + method), Android widgets from other apps.
- Wallpaper: nature pictures that follow the time of day (default), or the phone's own wallpaper.
- Name, icon/logo, colours, language. Personal use only, or shared as an APK (needs their own signing key)?

## 2. Tools on the PC

- JDK 17+: Android Studio ships one (`C:\Program Files\Android\Android Studio\jbr`). Android SDK with platform 34;
  Gradle downloads missing SDK parts by itself once the licences are accepted.
- adb: `platform-tools` from https://dl.google.com/android/repository/platform-tools-latest-windows.zip (ask first).
- Windows pitfalls seen on this machine:
  - Gradle fails with `Unable to establish loopback connection`: set
    `JAVA_TOOL_OPTIONS=-Djdk.net.unixdomain.tmpdir=D:/tmp -Djava.io.tmpdir=D:/tmp` (a short temp path with no spaces).
  - `local.properties`: `sdk.dir=D:/Android/SDK` with forward slashes (backslashes give "Invalid file path").
  - C: may be full; keep projects, Gradle caches and AVDs on D:.

Build: `./gradlew.bat assembleDebug` (debug) or `assembleRelease` (signed, see section 7).

## 3. Connect the phone

1. Settings > About phone > tap **Build number** 7 times (Xiaomi: **MIUI/HyperOS version**). Then Developer options >
   **USB debugging** on. Xiaomi also needs **Install via USB** and **USB debugging (Security settings)**, which ask
   for a Mi account sign-in the owner does themselves.
2. USB: `adb devices` and tell the owner to accept **Allow USB debugging?** on the phone.
3. Wi-Fi (Android 11+): Developer options > **Wireless debugging** > Pair device with pairing code;
   `adb pair IP:PAIR_PORT CODE` then `adb connect IP:PORT` (the port on the Wireless debugging screen, not the pairing one).
4. Read the facts: `adb shell getprop ro.product.manufacturer`, `ro.product.model`, `ro.build.version.sdk`,
   `wm size`, `wm density`.

## 4. Start from the template

Copy `template/` to a new folder on D:, then rename the package everywhere (`app/build.gradle` namespace +
applicationId, the `java/com/idiken/phonehome` folders and `package` lines) and `app_name` in `res/values/values.xml`.

| File | What it does |
|---|---|
| `MainActivity` | Home: builds the grid, item menus, drag start, empty-space menu, drawer, widget bind/configure flow, wallpaper choice, default-launcher request (RoleManager on 10+, Home settings before) |
| `HomeGrid` | 4x6 grid + dock row; layout from cells; drag and drop with a gold landing box, swap two apps, glide via `TransitionManager`; swipe up = drawer, swipe down = notifications, long press empty = menu |
| `Views` | App icon, `Clock` (time + Gregorian + Hijri), `Prayer` (strip when 1 row high, list when taller, next prayer gold), `WidgetView`/`Host` (long press over Android widgets), `Wallpaper` (time-of-day pictures) |
| `Sheets` | Floating menu next to the item, app drawer with search (Enter opens the first match), widget picker with previews |
| `Item`, `Store` | Grid model and saved layout; default dock found by intent (dialer, SMS, browser, camera), so it works on any brand |
| `PrayerTimes`, `Arabic` | Offline prayer times (Moroccan Habous: Fajr 19, Isha 17, +5 min Dhuhr/Maghrib, 30 cities), Arabic day/month names (Moroccan months), Umm al-Qura Hijri date |
| `Ui` | Tajawal font, shapes, `LauncherApps` app list and launch with a reveal animation |

Change what they asked for, nothing more. Keep the conventions: Java, plain framework views, Arabic strings in
code, `Ui.text()` for text, `Sheets.menu()` for any new menu.

## 5. Install and verify on the real phone

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n <package>/.MainActivity
adb exec-out screencap -p > shot.png      # then LOOK at the picture before saying it works
adb logcat -d -b crash | tail
```

Making it the default: the launcher's own menu ("اجعلها الواجهة الرئيسية") shows Android's dialog; the owner taps it.
For tests only, `adb shell cmd package set-home-activity <package>/.MainActivity`. Never disable or uninstall the
phone's stock launcher. The way back: Settings > Apps > Default apps > Home app.

Test checklist, with screenshots: tap opens an app; long press shows the menu AND lifts the icon; dragging closes the
menu and shows the gold box; drop on a free cell moves, on an app swaps; dock accepts apps only; swipe up opens the
drawer, search filters, swipe down at the top closes it; add an Android widget (the bind dialog appears once, then
its setup screen if it has one); resize a widget; wallpaper switch; Home closes any menu; Back never leaves;
install/uninstall an app refreshes the screen.

## 6. Pitfalls already met (do not rediscover them)

- Views added while a layout pass is running are never measured: add/rebuild children with `post()`.
- An `AppWidgetHostView` swallows long presses: the template's `WidgetView` intercepts them with a timer.
- List apps with `LauncherApps.getActivityList`, not `PackageManager` (no `QUERY_ALL_PACKAGES` needed); intents the
  dock looks for must be in `<queries>`.
- `ACTION_APPWIDGET_PICK` is missing or ugly on many phones: use the template's own picker +
  `bindAppWidgetIdIfAllowed` / `ACTION_APPWIDGET_BIND`, then `startAppWidgetConfigureActivityForResult`.
- Xiaomi MIUI/HyperOS: full-screen gestures only work with the stock launcher on many versions (third-party
  launchers fall back to buttons); Huawei EMUI may refuse third-party launchers. Say so before building.
- Morocco is UTC+1 (UTC+0 in Ramadan): use `Africa/Casablanca`. Online prayer APIs may return UTC+0 times.
- Android 13+ blocks reading another app's files in Download: an in-app backup must be imported through the
  system file picker (`ACTION_OPEN_DOCUMENT`), not a fixed path.
- Screenshots for docs: an emulator gives real ones (`emulator -avd <name> -no-window`); in `.ini` files use
  forward slashes (backslashes turned `\a`, `\t` into control characters).

## 7. Shipping it

- Signing: `keytool -genkeypair -keystore signing/release.jks -alias <name> -keyalg RSA -keysize 4096 -validity 36500`,
  passwords in `signing/keystore.properties`, read by `app/build.gradle`; `signing/` in `.gitignore`. Tell the owner
  to back it up: every update must use the same key.
- Bump `versionCode`/`versionName`, `assembleRelease`, `apksigner verify --print-certs`, give the APK a clear name.
- An About screen with the owner's name, site, licence and credits (wallpapers are CC BY-SA: name the photographers).
- GitHub: README with real screenshots, LICENSE, CREDITS, `.gitignore` without keys or APKs; check
  `git ls-tree -r --name-only HEAD` for secrets before every push; put the APK in Releases, not in the repo.
- Google Play is possible (launchers are allowed) but needs a developer account, an AAB, a privacy policy and,
  for new personal accounts, a 14-day closed test with 12 testers.
