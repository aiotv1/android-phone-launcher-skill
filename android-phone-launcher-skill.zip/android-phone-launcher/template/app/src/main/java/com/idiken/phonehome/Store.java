package com.idiken.phonehome;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.LauncherActivityInfo;
import android.net.Uri;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** The owner's home screen: layout, prayer city and wallpaper choice. */
final class Store {
    static final String LAYOUT = "layout", CITY = "city", WALLPAPER = "wallpaper";
    /** Wallpaper: "nature" (time-of-day pictures drawn by the launcher) or "system" (the phone's own). */
    static final String NATURE = "nature", SYSTEM = "system";

    private Store() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("home", Context.MODE_PRIVATE);
    }

    static String city(Context c) {
        return prefs(c).getString(CITY, PrayerTimes.CITIES[0].name);
    }

    static void save(Context c, List<Item> items) {
        prefs(c).edit().putString(LAYOUT, Item.toJson(items)).apply();
    }

    static List<Item> load(Context c, List<LauncherActivityInfo> apps) {
        String s = prefs(c).getString(LAYOUT, null);
        List<Item> items = s == null ? new ArrayList<>() : Item.fromJson(s);
        if (items.isEmpty()) items = defaults(c, apps);
        Set<String> installed = new HashSet<>();
        for (LauncherActivityInfo a : apps) installed.add(a.getComponentName().flattenToString());
        // An uninstalled app leaves its cell empty.
        items.removeIf(i -> i.isApp() && !installed.contains(i.component));
        return items;
    }

    /**
     * Clock on top, the five prayers as one strip under it, a few apps, and a dock with the phone,
     * messages, browser and camera found by what they do, not by package name, so it works on any brand.
     */
    static List<Item> defaults(Context c, List<LauncherActivityInfo> apps) {
        List<Item> items = new ArrayList<>();
        items.add(new Item(Item.CLOCK, "", 0, 0, 0, 4, 2));
        items.add(new Item(Item.PRAYER, "", 0, 0, 2, 4, 1));
        Intent[] dockIntents = {
                new Intent(Intent.ACTION_DIAL),
                new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                new Intent(Intent.ACTION_VIEW, Uri.parse("https://idiken.com")),
                new Intent(MediaStore.ACTION_IMAGE_CAPTURE)};
        Set<String> used = new HashSet<>();
        int x = 0;
        for (Intent i : dockIntents) {
            String comp = Ui.appFor(c, i, apps);
            if (comp == null || !used.add(comp)) continue;
            items.add(Item.app(comp, x++, Item.DOCK));
        }
        int cell = 0;
        for (LauncherActivityInfo a : apps) {
            String comp = a.getComponentName().flattenToString();
            if (used.contains(comp)) continue;
            int y = 4 + cell / Item.COLS;
            if (y >= Item.ROWS) break;
            // Right to left, as Arabic reads.
            items.add(Item.app(comp, Item.COLS - 1 - cell % Item.COLS, y));
            used.add(comp);
            cell++;
        }
        return items;
    }
}
