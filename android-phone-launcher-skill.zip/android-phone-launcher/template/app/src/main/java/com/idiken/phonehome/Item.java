package com.idiken.phonehome;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * One thing on the home screen: an app icon, an Android widget, or a built-in widget (clock, prayer times).
 * Positions are in grid cells; row {@link #DOCK} is the dock along the bottom.
 */
final class Item {
    static final String APP = "app", WIDGET = "widget", CLOCK = "clock", PRAYER = "prayer";
    static final int COLS = 4, ROWS = 6, DOCK = ROWS;

    final String type;
    /** For apps: the launcher activity, ComponentName.flattenToString(). */
    final String component;
    /** For Android widgets: the AppWidgetHost id. */
    final int widgetId;
    int x, y, w, h;

    Item(String type, String component, int widgetId, int x, int y, int w, int h) {
        this.type = type;
        this.component = component == null ? "" : component;
        this.widgetId = widgetId;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    static Item app(String component, int x, int y) {
        return new Item(APP, component, 0, x, y, 1, 1);
    }

    boolean isApp() {
        return APP.equals(type);
    }

    boolean inDock() {
        return y == DOCK;
    }

    boolean overlaps(int ox, int oy, int ow, int oh) {
        return x < ox + ow && ox < x + w && y < oy + oh && oy < y + h;
    }

    JSONObject toJson() throws JSONException {
        return new JSONObject().put("type", type).put("c", component).put("id", widgetId)
                .put("x", x).put("y", y).put("w", w).put("h", h);
    }

    static String toJson(List<Item> items) {
        JSONArray a = new JSONArray();
        try {
            for (Item i : items) a.put(i.toJson());
        } catch (JSONException ignored) {
            // plain strings and ints only
        }
        return a.toString();
    }

    static List<Item> fromJson(String s) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Item(o.getString("type"), o.optString("c"), o.optInt("id"), o.getInt("x"), o.getInt("y"),
                        Math.max(1, o.optInt("w", 1)), Math.max(1, o.optInt("h", 1))));
            }
        } catch (JSONException ignored) {
            // a broken layout falls back to the default one
        }
        return out;
    }
}
