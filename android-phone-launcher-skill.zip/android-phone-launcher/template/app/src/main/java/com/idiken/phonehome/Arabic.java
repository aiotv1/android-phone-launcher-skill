package com.idiken.phonehome;

import android.icu.util.IslamicCalendar;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Locale;

/** Arabic words for dates, countdowns and team names, written out here so old firmware ICU data doesn't matter. */
final class Arabic {
    private static final String[] DAYS = {"الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"};
    private static final String[] MONTHS = {"يناير", "فبراير", "مارس", "أبريل", "ماي", "يونيو", "يوليوز",
            "غشت", "شتنبر", "أكتوبر", "نونبر", "دجنبر"};
    private static final String[] HIJRI = {"محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى",
            "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"};

    private Arabic() {}

    static String weekday(LocalDate d) {
        return DAYS[d.getDayOfWeek().getValue() - 1];
    }

    /** "22 أكتوبر 2026" */
    static String gregorian(LocalDate d) {
        return d.getDayOfMonth() + " " + MONTHS[d.getMonthValue() - 1] + " " + d.getYear();
    }

    /** Umm al-Qura date, "1 جمادى الأولى 1448 هـ". */
    static String hijri(ZonedDateTime now) {
        IslamicCalendar cal = new IslamicCalendar();
        cal.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
        cal.setTimeInMillis(now.toInstant().toEpochMilli());
        return cal.get(IslamicCalendar.DAY_OF_MONTH) + " " + HIJRI[cal.get(IslamicCalendar.MONTH)] + " "
                + cal.get(IslamicCalendar.YEAR) + " هـ";
    }

    /** "بعد 1 س 14 د" or "بعد 9 د". */
    static String countdown(long minutes) {
        if (minutes >= 60) return "بعد " + (minutes / 60) + " س " + (minutes % 60) + " د";
        return "بعد " + minutes + " د";
    }

    static String greeting(int hour) {
        if (hour < 5) return "طابت ليلتك";
        if (hour < 12) return "صباح الخير";
        if (hour < 18) return "مساء الخير";
        return "مساء النور";
    }

    /** Arabic names for the teams the match feed shows; anything else keeps the source's name. */
    private static final String[][] TEAMS = {
            {"real madrid", "ريال مدريد"}, {"barcelona", "برشلونة"}, {"atlético", "أتلتيكو مدريد"},
            {"atletico", "أتلتيكو مدريد"}, {"man city", "مانشستر سيتي"}, {"manchester city", "مانشستر سيتي"},
            {"man united", "مانشستر يونايتد"}, {"manchester united", "مانشستر يونايتد"}, {"liverpool", "ليفربول"},
            {"arsenal", "آرسنال"}, {"chelsea", "تشيلسي"}, {"tottenham", "توتنهام"}, {"bayern", "بايرن ميونخ"},
            {"dortmund", "دورتموند"}, {"paris saint", "باريس سان جيرمان"}, {"psg", "باريس سان جيرمان"},
            {"juventus", "يوفنتوس"}, {"internazionale", "إنتر ميلان"}, {"inter milan", "إنتر ميلان"},
            {"napoli", "نابولي"}, {"marseille", "مارسيليا"}, {"morocco", "المغرب"}, {"raja", "الرجاء"},
            {"wydad", "الوداد"}, {"far rabat", "الجيش الملكي"}, {"as far", "الجيش الملكي"},
            {"berkane", "نهضة بركان"}, {"al ahly", "الأهلي"}, {"zamalek", "الزمالك"}, {"rennes", "رين"},
            {"lyon", "ليون"}, {"monaco", "موناكو"}, {"lille", "ليل"}, {"roma", "روما"}, {"lazio", "لاتسيو"},
            {"sevilla", "إشبيلية"}, {"villarreal", "فياريال"}, {"betis", "ريال بيتيس"}, {"newcastle", "نيوكاسل"},
            {"aston villa", "أستون فيلا"}, {"leverkusen", "باير ليفركوزن"}, {"bournemouth", "بورنموث"},
            {"algeria", "الجزائر"}, {"tunisia", "تونس"}, {"egypt", "مصر"}, {"senegal", "السنغال"},
            {"france", "فرنسا"}, {"spain", "إسبانيا"}, {"portugal", "البرتغال"}, {"brazil", "البرازيل"},
            {"argentina", "الأرجنتين"}};

    static String team(String name) {
        String n = name.toLowerCase(Locale.ROOT).trim();
        if (n.equals("inter") || n.equals("milan") || n.equals("ac milan")) return n.equals("inter") ? "إنتر ميلان" : "ميلان";
        for (String[] t : TEAMS) if (n.contains(t[0])) return t[1];
        return name;
    }
}
