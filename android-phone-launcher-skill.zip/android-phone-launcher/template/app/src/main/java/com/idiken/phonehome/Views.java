package com.idiken.phonehome;

import android.annotation.SuppressLint;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.pm.LauncherActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.io.InputStream;
import java.time.Duration;
import java.time.ZonedDateTime;

/** The views placed on the grid, plus the launcher's wallpaper. */
final class Views {
    private Views() {}

    /** Anything on the grid that refreshes once a minute. */
    interface Minute {
        void onMinute();
    }

    /** An app: icon and name; the name is hidden in the dock. */
    static View icon(Context c, LauncherActivityInfo info, boolean label) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        ImageView img = new ImageView(c);
        img.setImageDrawable(Ui.icon(c, info));
        int s = (int) Ui.dp(c, 54);
        v.addView(img, new LinearLayout.LayoutParams(s, s));
        if (label) {
            TextView t = Ui.onWallpaper(c, info.getLabel(), 12, 500);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setGravity(Gravity.CENTER);
            t.setPadding((int) Ui.dp(c, 4), (int) Ui.dp(c, 6), (int) Ui.dp(c, 4), 0);
            v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        }
        // A small squeeze under the finger.
        v.setOnTouchListener((view, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start();
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL)
                view.animate().scaleX(1f).scaleY(1f).setDuration(160).start();
            return false;
        });
        return v;
    }

    /** Big time, the day and both dates, straight on the wallpaper. */
    static final class Clock extends LinearLayout implements Minute {
        private final TextView date;

        Clock(Context c) {
            super(c);
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);
            TextClock time = new TextClock(c);
            time.setFormat12Hour("HH:mm");
            time.setFormat24Hour("HH:mm");
            time.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 76);
            time.setTypeface(Ui.font(c, 300));
            time.setTextColor(0xFFFFFFFF);
            time.setIncludeFontPadding(false);
            time.setShadowLayer(Ui.dp(c, 10), 0, Ui.dp(c, 2), 0x80000000);
            time.setGravity(Gravity.CENTER);
            addView(time, new LayoutParams(-1, -2));
            date = Ui.onWallpaper(c, "", 15, 500);
            date.setGravity(Gravity.CENTER);
            addView(date);
            onMinute();
        }

        @Override
        public void onMinute() {
            ZonedDateTime now = ZonedDateTime.now();
            date.setText(Arabic.weekday(now.toLocalDate()) + " · " + Arabic.gregorian(now.toLocalDate()) + "\n" + Arabic.hijri(now));
        }
    }

    /** The five prayers: one strip when the widget is a single row high, a list when taller. The next is gold. */
    static final class Prayer extends LinearLayout implements Minute {
        private final Item item;

        Prayer(Context c, Item item) {
            super(c);
            this.item = item;
            setBackground(Ui.glass(c));
            int p = (int) Ui.dp(c, 10);
            setPadding(p, p, p, p);
            onMinute();
        }

        @Override
        public void onMinute() {
            Context c = getContext();
            removeAllViews();
            boolean strip = item.h == 1;
            setOrientation(strip ? HORIZONTAL : VERTICAL);
            setLayoutDirection(LAYOUT_DIRECTION_RTL);
            PrayerTimes.City city = PrayerTimes.city(Store.city(c));
            ZonedDateTime now = ZonedDateTime.now(PrayerTimes.MOROCCO);
            ZonedDateTime[] t = PrayerTimes.forDate(city, now.toLocalDate(), PrayerTimes.MOROCCO);
            Object[] next = PrayerTimes.next(city, now);
            int ni = (int) next[0];
            if (!strip) {
                TextView head = Ui.text(c, "مواقيت الصلاة · " + city.arabic, 13, 500, 0xB3FFFFFF);
                head.setPadding((int) Ui.dp(c, 6), 0, (int) Ui.dp(c, 6), (int) Ui.dp(c, 6));
                addView(head);
            }
            for (int i = 0; i < 5; i++) {
                boolean isNext = i == ni;
                LinearLayout cell = new LinearLayout(c);
                cell.setOrientation(strip ? VERTICAL : HORIZONTAL);
                cell.setLayoutDirection(LAYOUT_DIRECTION_RTL);
                cell.setGravity(Gravity.CENTER);
                int pad = (int) Ui.dp(c, strip ? 4 : 8);
                cell.setPadding(pad, pad, pad, pad);
                if (isNext) cell.setBackground(Ui.rounded(Ui.GOLD, Ui.dp(c, 14)));
                int color = isNext ? 0xFF15161A : (t[i].isBefore(now) && ni != 0 ? 0x80FFFFFF : 0xF2FFFFFF);
                TextView name = Ui.text(c, PrayerTimes.NAMES[i], strip ? 12 : 16, isNext ? 700 : 500, color);
                TextView time = Ui.text(c, PrayerTimes.hhmm(t[i]), strip ? 15 : 17, isNext ? 700 : 400, color);
                name.setGravity(Gravity.CENTER);
                time.setGravity(Gravity.CENTER);
                if (strip) {
                    cell.addView(name);
                    time.setPadding(0, (int) Ui.dp(c, 4), 0, 0);
                    cell.addView(time);
                    addView(cell, new LayoutParams(0, -1, 1));
                } else {
                    cell.addView(name, new LayoutParams(0, -2, 1));
                    if (isNext) {
                        long m = Math.max(0, Duration.between(now, (ZonedDateTime) next[1]).toMinutes() + 1);
                        TextView in = Ui.text(c, Arabic.countdown(m), 12, 500, 0xB315161A);
                        in.setPadding((int) Ui.dp(c, 8), 0, (int) Ui.dp(c, 8), 0);
                        cell.addView(in);
                    }
                    cell.addView(time);
                    addView(cell, new LayoutParams(-1, 0, 1));
                }
            }
        }
    }

    /**
     * An Android widget's view that lets the launcher see a long press (to move or remove it) even though
     * the widget's own buttons take the touches.
     */
    static final class WidgetView extends AppWidgetHostView {
        private boolean longPressed;
        private float downX, downY;
        private final Runnable longPress = () -> {
            longPressed = true;
            performLongClick();
        };

        WidgetView(Context c) {
            super(c);
        }

        @SuppressLint("ClickableViewAccessibility")
        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            if (longPressed) {
                if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) longPressed = false;
                return true;
            }
            int slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (Math.hypot(e.getX() - downX, e.getY() - downY) > slop) removeCallbacks(longPress);
                    break;
                default:
                    removeCallbacks(longPress);
            }
            return false;
        }
    }

    static final class Host extends AppWidgetHost {
        Host(Context c) {
            super(c, 1024);
        }

        @Override
        protected AppWidgetHostView onCreateView(Context c, int id, AppWidgetProviderInfo info) {
            return new WidgetView(c);
        }
    }

    /** Nature pictures that follow the sun over the prayer city: dawn, day, sunset and night. */
    static final class Wallpaper extends FrameLayout {
        private final ImageView[] layers = new ImageView[2];
        private int front;
        private String shown = "";

        Wallpaper(Context c) {
            super(c);
            for (int i = 0; i < 2; i++) {
                layers[i] = new ImageView(c);
                layers[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
                layers[i].setAlpha(0f);
                addView(layers[i], new LayoutParams(-1, -1));
            }
            View shade = new View(c);
            shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0x66000000, 0x00000000, 0x00000000, 0x80000000}));
            addView(shade, new LayoutParams(-1, -1));
        }

        static String sceneNow(Context c) {
            ZonedDateTime now = ZonedDateTime.now(PrayerTimes.MOROCCO);
            ZonedDateTime[] t = PrayerTimes.forDate(PrayerTimes.city(Store.city(c)), now.toLocalDate(), PrayerTimes.MOROCCO);
            if (now.isBefore(t[0])) return "night";
            if (now.isBefore(t[0].plusMinutes(150))) return "dawn";
            if (now.isBefore(t[3].minusMinutes(50))) return "day";
            if (now.isBefore(t[4].plusMinutes(20))) return "sunset";
            return "night";
        }

        void update() {
            boolean nature = Store.NATURE.equals(Store.prefs(getContext()).getString(Store.WALLPAPER, Store.NATURE));
            setVisibility(nature ? VISIBLE : GONE);
            if (!nature) {
                shown = "";
                return;
            }
            String want = sceneNow(getContext());
            if (want.equals(shown)) return;
            Bitmap b;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            try (InputStream in = getContext().getAssets().open("wallpapers/" + want + ".jpg")) {
                b = BitmapFactory.decodeStream(in, null, o);
            } catch (Exception e) {
                return;
            }
            shown = want;
            ImageView next = layers[1 - front], old = layers[front];
            next.setImageBitmap(b);
            next.bringToFront();
            bringShadeToFront();   // the shade stays above both pictures
            next.setAlpha(0f);
            next.animate().alpha(1f).setDuration(old.getDrawable() == null ? 300 : 1500).withEndAction(() -> {
                old.setImageDrawable(null);
                old.setAlpha(0f);
            }).start();
            front = 1 - front;
        }

        private void bringShadeToFront() {
            for (int i = 0; i < getChildCount(); i++) {
                View v = getChildAt(i);
                if (!(v instanceof ImageView)) {
                    v.bringToFront();
                    return;
                }
            }
        }
    }
}
