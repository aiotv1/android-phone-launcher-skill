package com.idiken.phonehome;

import android.annotation.SuppressLint;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.pm.LauncherActivityInfo;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/** Layers over the home screen: the floating menu, the app drawer and the widget picker. One at a time. */
final class Sheets {
    private Sheets() {}

    /** A menu row: icon, label, action. */
    static final class Row {
        final int icon;
        final String label;
        final Runnable run;

        Row(int icon, String label, Runnable run) {
            this.icon = icon;
            this.label = label;
            this.run = run;
        }
    }

    /** A dimmed layer that closes on a tap outside its content or on Back. */
    static class Layer extends FrameLayout {
        Runnable onClosed;
        private boolean closing;

        Layer(Context c, int dim) {
            super(c);
            setBackgroundColor(dim);
            setAlpha(0f);
            animate().alpha(1f).setDuration(150).start();
            setOnClickListener(v -> close());
        }

        void close() {
            ViewGroup p = (ViewGroup) getParent();
            if (p == null || closing) return;
            closing = true;
            animate().alpha(0f).setDuration(130).withEndAction(() -> p.removeView(this)).start();
            if (onClosed != null) onClosed.run();
        }

        boolean isOpen() {
            return getParent() != null && !closing;
        }
    }

    /** A small glass menu next to anchor (screen rect), above it when the anchor sits low. */
    static Layer menu(ViewGroup root, String title, List<Row> rows, RectF anchor) {
        Context c = root.getContext();
        Layer layer = new Layer(c, 0x33000000);
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.rounded(0xF51C1D22, Ui.dp(c, 22)));
        card.setElevation(Ui.dp(c, 16));
        int p = (int) Ui.dp(c, 8);
        card.setPadding(p, p, p, p);
        card.setClickable(true);
        if (title != null) {
            TextView t = Ui.text(c, title, 13, 700, 0x99FFFFFF);
            t.setGravity(Gravity.END);
            t.setPadding(p * 2, p, p * 2, p);
            card.addView(t, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        for (Row r : rows) list.addView(row(c, layer, r), new LinearLayout.LayoutParams(-1, (int) Ui.dp(c, 50)));
        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(list);
        card.addView(scroll);
        int width = (int) Ui.dp(c, 260);
        int maxH = (int) (root.getHeight() * 0.7f);
        card.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST));
        int h = Math.min(card.getMeasuredHeight(), maxH);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, h);
        float m = Ui.dp(c, 12);
        if (anchor == null) {
            lp.gravity = Gravity.CENTER;
        } else {
            lp.leftMargin = (int) Math.max(m, Math.min(root.getWidth() - width - m, anchor.centerX() - width / 2f));
            boolean above = anchor.centerY() > root.getHeight() / 2f;
            float top = above ? anchor.top - h - m : anchor.bottom + m;
            lp.topMargin = (int) Math.max(m, Math.min(root.getHeight() - h - m, top));
            card.setPivotY(above ? h : 0);
        }
        layer.addView(card, lp);
        card.setScaleX(0.9f);
        card.setScaleY(0.9f);
        card.animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(new DecelerateInterpolator(2f)).start();
        root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        return layer;
    }

    private static View row(Context c, Layer layer, Row r) {
        LinearLayout row = new LinearLayout(c);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int p = (int) Ui.dp(c, 14);
        row.setPadding(p, 0, p, 0);
        row.setBackground(c.getDrawable(android.R.drawable.list_selector_background));
        if (r.icon != 0) {
            ImageView i = new ImageView(c);
            i.setImageResource(r.icon);
            i.setColorFilter(0xE6FFFFFF);
            int s = (int) Ui.dp(c, 22);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s, s);
            lp.setMarginEnd(p);
            row.addView(i, lp);
        }
        row.addView(Ui.text(c, r.label, 16, 500, 0xFFFFFFFF));
        row.setOnClickListener(v -> {
            layer.close();
            r.run.run();
        });
        return row;
    }

    // ---- app drawer -------------------------------------------------------------------------------------

    /** Every app with a search box; tap opens, long press offers "add to home". Swipe down closes. */
    @SuppressLint("ClickableViewAccessibility")
    static Layer drawer(ViewGroup root, List<LauncherActivityInfo> all, int topInset,
                        Consumer<LauncherActivityInfo> open, Consumer<LauncherActivityInfo> menu) {
        Context c = root.getContext();
        Layer layer = new Layer(c, 0xF20E0F12);
        layer.setOnClickListener(null);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        int side = (int) Ui.dp(c, 16);
        col.setPadding(side, topInset + side, side, 0);
        View handle = new View(c);
        handle.setBackground(Ui.rounded(0x66FFFFFF, Ui.dp(c, 3)));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams((int) Ui.dp(c, 40), (int) Ui.dp(c, 5));
        hl.gravity = Gravity.CENTER_HORIZONTAL;
        hl.bottomMargin = side;
        col.addView(handle, hl);
        EditText search = new EditText(c);
        search.setHint("ابحث عن تطبيق");
        search.setHintTextColor(0x80FFFFFF);
        search.setTextColor(0xFFFFFFFF);
        search.setTypeface(Ui.font(c, 500));
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        search.setBackground(Ui.rounded(0x1FFFFFFF, Ui.dp(c, 24)));
        int sp = (int) Ui.dp(c, 18);
        search.setPadding(sp, 0, sp, 0);
        col.addView(search, new LinearLayout.LayoutParams(-1, (int) Ui.dp(c, 48)));
        List<LauncherActivityInfo> shown = new ArrayList<>(all);
        GridView grid = new GridView(c);
        grid.setNumColumns(4);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        grid.setVerticalSpacing((int) Ui.dp(c, 18));
        grid.setPadding(0, side, 0, side * 3);
        grid.setClipToPadding(false);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        grid.setVerticalScrollBarEnabled(false);
        BaseAdapter adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View convert, ViewGroup parent) {
                View v = Views.icon(c, shown.get(i), true);
                v.setLayoutParams(new GridView.LayoutParams(-1, (int) Ui.dp(c, 92)));
                return v;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, i, id) -> open.accept(shown.get(i)));
        grid.setOnItemLongClickListener((p, v, i, id) -> {
            menu.accept(shown.get(i));
            return true;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) {}

            @Override
            public void afterTextChanged(Editable s) {
                String q = s.toString().trim().toLowerCase(Locale.ROOT);
                shown.clear();
                for (LauncherActivityInfo a : all) if (a.getLabel().toString().toLowerCase(Locale.ROOT).contains(q)) shown.add(a);
                adapter.notifyDataSetChanged();
            }
        });
        // Enter on the keyboard opens the first match.
        search.setOnEditorActionListener((v, action, ev) -> {
            if (!shown.isEmpty()) open.accept(shown.get(0));
            return true;
        });
        col.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        layer.addView(col, new FrameLayout.LayoutParams(-1, -1));
        GestureDetector down = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                boolean atTop = grid.getFirstVisiblePosition() == 0 && (grid.getChildCount() == 0 || grid.getChildAt(0).getTop() >= grid.getPaddingTop());
                if (vy > Ui.dp(c, 700) && atTop) {
                    hideKeyboard(search);
                    layer.close();
                    return true;
                }
                return false;
            }
        });
        grid.setOnTouchListener((v, e) -> {
            down.onTouchEvent(e);
            return false;
        });
        handle.setOnClickListener(v -> layer.close());
        col.setTranslationY(root.getHeight() * 0.25f);
        col.animate().translationY(0).setDuration(260).setInterpolator(new DecelerateInterpolator(2.2f)).start();
        root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        return layer;
    }

    static void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    // ---- widget picker ----------------------------------------------------------------------------------

    /** Built-in widgets first, then every Android widget on the phone, with its preview. */
    static Layer widgets(ViewGroup root, int topInset, Consumer<String> builtIn, Consumer<AppWidgetProviderInfo> android) {
        Context c = root.getContext();
        Layer layer = new Layer(c, 0xF20E0F12);
        layer.setOnClickListener(null);
        LinearLayout list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        int side = (int) Ui.dp(c, 16);
        list.setPadding(side, topInset + side, side, side * 3);
        TextView title = Ui.text(c, "إضافة ويدجت", 26, 700, 0xFFFFFFFF);
        title.setGravity(Gravity.END);
        title.setPadding(0, 0, 0, side);
        list.addView(title, new LinearLayout.LayoutParams(-1, -2));
        list.addView(widgetRow(c, layer, R.drawable.ic_clock, "الساعة والتاريخ", "مدمجة", null, () -> builtIn.accept(Item.CLOCK)));
        list.addView(widgetRow(c, layer, R.drawable.ic_moon, "مواقيت الصلاة", "مدمجة", null, () -> builtIn.accept(Item.PRAYER)));
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        List<AppWidgetProviderInfo> providers = new ArrayList<>(m.getInstalledProviders());
        providers.sort((a, b) -> a.loadLabel(c.getPackageManager()).compareToIgnoreCase(b.loadLabel(c.getPackageManager())));
        int dpi = c.getResources().getDisplayMetrics().densityDpi;
        for (AppWidgetProviderInfo p : providers) {
            String app;
            try {
                app = c.getPackageManager().getApplicationLabel(c.getPackageManager().getApplicationInfo(p.provider.getPackageName(), 0)).toString();
            } catch (Exception e) {
                app = p.provider.getPackageName();
            }
            Drawable preview = p.loadPreviewImage(c, dpi);
            if (preview == null) preview = p.loadIcon(c, dpi);
            list.addView(widgetRow(c, layer, 0, p.loadLabel(c.getPackageManager()), app, preview, () -> android.accept(p)));
        }
        ScrollView scroll = new ScrollView(c);
        scroll.addView(list);
        layer.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        return layer;
    }

    private static View widgetRow(Context c, Layer layer, int icon, String label, String sub, Drawable preview, Runnable pick) {
        LinearLayout row = new LinearLayout(c);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.rounded(0x14FFFFFF, Ui.dp(c, 18)));
        int p = (int) Ui.dp(c, 12);
        row.setPadding(p, p, p, p);
        ImageView img = new ImageView(c);
        if (preview != null) img.setImageDrawable(preview);
        else {
            img.setImageResource(icon);
            img.setColorFilter(Ui.GOLD);
        }
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int s = (int) Ui.dp(c, 64);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(s, s);
        il.setMarginEnd(p);
        row.addView(img, il);
        LinearLayout text = new LinearLayout(c);
        text.setOrientation(LinearLayout.VERTICAL);
        text.addView(Ui.text(c, label, 16, 700, 0xFFFFFFFF));
        TextView subView = Ui.text(c, sub, 12, 400, 0x99FFFFFF);
        subView.setPadding(0, (int) Ui.dp(c, 4), 0, 0);
        text.addView(subView);
        row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        row.setOnClickListener(v -> {
            layer.close();
            pick.run();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = (int) Ui.dp(c, 10);
        row.setLayoutParams(lp);
        return row;
    }
}
