package com.idiken.phonehome;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.content.pm.ResolveInfo;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Process;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Shared bits: units, the Tajawal font, rounded shapes, and the apps the launcher can show and open. */
final class Ui {
    static final int GOLD = 0xFFE9C46A;
    private static Typeface light, regular, medium, bold;

    private Ui() {}

    static float dp(Context c, float v) {
        return v * c.getResources().getDisplayMetrics().density;
    }

    static Typeface font(Context c, int weight) {
        if (regular == null) {
            light = c.getResources().getFont(R.font.tajawal_light);
            regular = c.getResources().getFont(R.font.tajawal_regular);
            medium = c.getResources().getFont(R.font.tajawal_medium);
            bold = c.getResources().getFont(R.font.tajawal_bold);
        }
        return weight <= 300 ? light : weight <= 400 ? regular : weight <= 500 ? medium : bold;
    }

    static TextView text(Context c, CharSequence s, float sp, int weight, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTypeface(font(c, weight));
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        return t;
    }

    /** White text that stays readable on any wallpaper. */
    static TextView onWallpaper(Context c, CharSequence s, float sp, int weight) {
        TextView t = text(c, s, sp, weight, 0xFFFFFFFF);
        t.setShadowLayer(dp(c, 6), 0, dp(c, 1), 0x99000000);
        return t;
    }

    static GradientDrawable rounded(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    /** Frosted dark card for widgets and sheets. */
    static GradientDrawable glass(Context c) {
        GradientDrawable d = rounded(0x99121318, dp(c, 24));
        d.setStroke(Math.max(1, (int) dp(c, 1)), 0x26FFFFFF);
        return d;
    }

    static void clipRounded(View v, float radius) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline o) {
                o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        v.setClipToOutline(true);
    }

    // ---- apps ---------------------------------------------------------------------------------------------

    static LauncherApps launcherApps(Context c) {
        return (LauncherApps) c.getSystemService(Context.LAUNCHER_APPS_SERVICE);
    }

    /** Every launchable activity of this user, sorted by label (LauncherApps sees them without QUERY_ALL_PACKAGES). */
    static List<LauncherActivityInfo> apps(Context c) {
        List<LauncherActivityInfo> list = new ArrayList<>();
        for (LauncherActivityInfo i : launcherApps(c).getActivityList(null, Process.myUserHandle())) {
            if (!i.getComponentName().getPackageName().equals(c.getPackageName())) list.add(i);
        }
        list.sort((a, b) -> a.getLabel().toString().compareToIgnoreCase(b.getLabel().toString()));
        return list;
    }

    static LauncherActivityInfo find(Context c, String component) {
        ComponentName cn = ComponentName.unflattenFromString(component);
        if (cn == null) return null;
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn);
        return launcherApps(c).resolveActivity(i, Process.myUserHandle());
    }

    static Drawable icon(Context c, LauncherActivityInfo info) {
        return info.getBadgedIcon(c.getResources().getDisplayMetrics().densityDpi);
    }

    static void launch(Context c, String component, View from) {
        ComponentName cn = ComponentName.unflattenFromString(component);
        if (cn == null) return;
        android.graphics.Rect bounds = null;
        android.os.Bundle opts = null;
        if (from != null) {
            int[] at = new int[2];
            from.getLocationOnScreen(at);
            bounds = new android.graphics.Rect(at[0], at[1], at[0] + from.getWidth(), at[1] + from.getHeight());
            opts = android.app.ActivityOptions.makeClipRevealAnimation(from, 0, 0, from.getWidth(), from.getHeight()).toBundle();
        }
        try {
            launcherApps(c).startMainActivity(cn, Process.myUserHandle(), bounds, opts);
        } catch (Exception e) {
            android.widget.Toast.makeText(c, "تعذّر فتح التطبيق", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    /** The app that answers an intent (dialer, messages, browser, camera), as a launcher component, or null. */
    static String appFor(Context c, Intent intent, List<LauncherActivityInfo> apps) {
        ResolveInfo r = c.getPackageManager().resolveActivity(intent, 0);
        if (r == null || r.activityInfo == null) return null;
        String pkg = r.activityInfo.packageName;
        for (LauncherActivityInfo i : apps) if (i.getComponentName().getPackageName().equals(pkg)) return i.getComponentName().flattenToString();
        return null;
    }
}
