package com.idiken.phonehome;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * The five daily prayers for one city, computed on the TV with no network: the classic solar-angle
 * method (praytimes.org) with Morocco's Habous parameters - Fajr at 19 degrees, Isha at 17 degrees,
 * Asr at one shadow length, and 5 minutes of caution added to Dhuhr and Maghrib (as AlAdhan method 21).
 */
final class PrayerTimes {

    static final class City {
        final String name, arabic;
        final double lat, lon;

        City(String name, String arabic, double lat, double lon) {
            this.name = name;
            this.arabic = arabic;
            this.lat = lat;
            this.lon = lon;
        }
    }

    /** Moroccan cities offered in Launcher settings; the first is the default. */
    static final City[] CITIES = {
            new City("Casablanca", "الدار البيضاء", 33.5731, -7.5898),
            new City("Rabat", "الرباط", 34.0209, -6.8416),
            new City("Marrakech", "مراكش", 31.6295, -7.9811),
            new City("Fes", "فاس", 34.0181, -5.0078),
            new City("Tangier", "طنجة", 35.7595, -5.8340),
            new City("Agadir", "أكادير", 30.4278, -9.5981),
            new City("Meknes", "مكناس", 33.8935, -5.5473),
            new City("Oujda", "وجدة", 34.6814, -1.9086),
            new City("Kenitra", "القنيطرة", 34.2610, -6.5802),
            new City("Tetouan", "تطوان", 35.5889, -5.3626),
            new City("Safi", "آسفي", 32.2994, -9.2372),
            new City("El Jadida", "الجديدة", 33.2316, -8.5007),
            new City("Mohammedia", "المحمدية", 33.6866, -7.3830),
            new City("Beni Mellal", "بني ملال", 32.3373, -6.3498),
            new City("Khouribga", "خريبكة", 32.8811, -6.9063),
            new City("Settat", "سطات", 33.0010, -7.6166),
            new City("Berrechid", "برشيد", 33.2655, -7.5875),
            new City("Nador", "الناظور", 35.1740, -2.9287),
            new City("Al Hoceima", "الحسيمة", 35.2517, -3.9372),
            new City("Taza", "تازة", 34.2100, -4.0100),
            new City("Larache", "العرائش", 35.1932, -6.1557),
            new City("Khemisset", "الخميسات", 33.8241, -6.0661),
            new City("Ifrane", "إفران", 33.5228, -5.1106),
            new City("Errachidia", "الرشيدية", 31.9314, -4.4246),
            new City("Ouarzazate", "ورزازات", 30.9189, -6.8934),
            new City("Essaouira", "الصويرة", 31.5085, -9.7595),
            new City("Taroudant", "تارودانت", 30.4703, -8.8770),
            new City("Guelmim", "كلميم", 28.9870, -10.0574),
            new City("Laayoune", "العيون", 27.1253, -13.1625),
            new City("Dakhla", "الداخلة", 23.6848, -15.9580),
    };

    static final String[] NAMES = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
    static final ZoneId MOROCCO = ZoneId.of("Africa/Casablanca");

    private static final double FAJR_ANGLE = 19, ISHA_ANGLE = 17;
    private static final int DHUHR_OFFSET_MIN = 5, MAGHRIB_OFFSET_MIN = 5;

    static City city(String name) {
        for (City c : CITIES) if (c.name.equals(name)) return c;
        return CITIES[0];
    }

    /** Fajr, Dhuhr, Asr, Maghrib and Isha for that date, in the city's time zone. */
    static ZonedDateTime[] forDate(City city, LocalDate date, ZoneId zone) {
        double jd = julian(date) - city.lon / (15 * 24.0);
        double[] t = {5, 12, 13, 18, 18};   // first guesses in local solar hours, refined below
        for (int pass = 0; pass < 2; pass++) {
            t = new double[]{
                    sunAngleTime(jd, FAJR_ANGLE, t[0], true, city.lat),
                    midDay(jd, t[1]),
                    asrTime(jd, t[2], city.lat),
                    sunAngleTime(jd, 0.833, t[3], false, city.lat),
                    sunAngleTime(jd, ISHA_ANGLE, t[4], false, city.lat)};
        }
        ZonedDateTime midnightUtc = date.atStartOfDay(ZoneId.of("UTC"));
        ZonedDateTime[] out = new ZonedDateTime[5];
        int[] offsets = {0, DHUHR_OFFSET_MIN, 0, MAGHRIB_OFFSET_MIN, 0};
        for (int i = 0; i < 5; i++) {
            double utcHours = t[i] - city.lon / 15.0;
            // Published tables round up to the next minute.
            long minutes = (long) Math.ceil(utcHours * 60) + offsets[i];
            out[i] = midnightUtc.plusMinutes(minutes).withZoneSameInstant(zone);
        }
        return out;
    }

    /** The next prayer from now (index into NAMES and its time); after Isha, tomorrow's Fajr. */
    static Object[] next(City city, ZonedDateTime now) {
        ZonedDateTime[] today = forDate(city, now.toLocalDate(), now.getZone());
        for (int i = 0; i < 5; i++) if (today[i].isAfter(now)) return new Object[]{i, today[i]};
        return new Object[]{0, forDate(city, now.toLocalDate().plusDays(1), now.getZone())[0]};
    }

    static String hhmm(ZonedDateTime t) {
        LocalTime l = t.toLocalTime();
        return String.format(java.util.Locale.US, "%02d:%02d", l.getHour(), l.getMinute());
    }

    // ---- astronomy (praytimes.org) --------------------------------------------------------------

    private static double julian(LocalDate d) {
        int y = d.getYear(), m = d.getMonthValue(), day = d.getDayOfMonth();
        if (m <= 2) {
            y -= 1;
            m += 12;
        }
        double a = Math.floor(y / 100.0);
        double b = 2 - a + Math.floor(a / 4);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + b - 1524.5;
    }

    /** {declination, equation of time} for a Julian date. */
    private static double[] sun(double jd) {
        double d = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * d);
        double q = fixAngle(280.459 + 0.98564736 * d);
        double l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g));
        double e = 23.439 - 0.00000036 * d;
        double ra = darctan2(dcos(e) * dsin(l), dcos(l)) / 15;
        double eqt = q / 15 - fixHour(ra);
        double decl = darcsin(dsin(e) * dsin(l));
        return new double[]{decl, eqt};
    }

    private static double midDay(double jd, double time) {
        double eqt = sun(jd + time / 24)[1];
        return fixHour(12 - eqt);
    }

    private static double sunAngleTime(double jd, double angle, double time, boolean ccw, double lat) {
        double decl = sun(jd + time / 24)[0];
        double noon = midDay(jd, time);
        double cos = (-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat));
        double t = darccos(Math.max(-1, Math.min(1, cos))) / 15;
        return noon + (ccw ? -t : t);
    }

    private static double asrTime(double jd, double time, double lat) {
        double decl = sun(jd + time / 24)[0];
        double angle = -darccot(1 + dtan(Math.abs(lat - decl)));
        return sunAngleTime(jd, angle, time, false, lat);
    }

    private static double dsin(double d) { return Math.sin(Math.toRadians(d)); }
    private static double dcos(double d) { return Math.cos(Math.toRadians(d)); }
    private static double dtan(double d) { return Math.tan(Math.toRadians(d)); }
    private static double darcsin(double x) { return Math.toDegrees(Math.asin(x)); }
    private static double darccos(double x) { return Math.toDegrees(Math.acos(x)); }
    private static double darctan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }
    private static double darccot(double x) { return Math.toDegrees(Math.atan(1 / x)); }
    private static double fixAngle(double a) { a = a - 360 * Math.floor(a / 360); return a < 0 ? a + 360 : a; }
    private static double fixHour(double a) { a = a - 24 * Math.floor(a / 24); return a < 0 ? a + 24 : a; }
}
