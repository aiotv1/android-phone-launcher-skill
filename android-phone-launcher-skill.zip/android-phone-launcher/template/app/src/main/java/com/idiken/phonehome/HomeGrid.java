package com.idiken.phonehome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.transition.ChangeBounds;
import android.transition.TransitionManager;
import android.view.DragEvent;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

/**
 * The home screen: a 4 x 6 grid above a dock row. Children carry their {@link Item} as tag. Items are
 * dragged with a long press and dropped on any free cell (two apps swap places); everything glides to its
 * new spot. A swipe up opens the app drawer, a swipe down the notifications, a long press on empty space
 * the home menu.
 */
final class HomeGrid extends ViewGroup {
    interface Listener {
        void onLayoutChanged();

        void onEmptyLongPress(float x, float y);

        void onSwipeUp();

        void onSwipeDown();

        /** The finger moved this far since the drag started (to close the item's menu once it really moves). */
        void onDragMoved(float distance);
    }

    private Listener listener;
    private int insetTop, insetBottom;
    private final float dockHeight, pad;
    private final Paint hover = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RectF hoverRect;
    private boolean hoverOk;
    private float dragStartX = -1, dragStartY;
    private final GestureDetector gestures;

    HomeGrid(Context c) {
        super(c);
        dockHeight = Ui.dp(c, 96);
        pad = Ui.dp(c, 12);
        setClipChildren(false);
        setWillNotDraw(false);
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                if (childAt(e.getX(), e.getY()) == null && listener != null) listener.onEmptyLongPress(e.getX(), e.getY());
            }

            @Override
            public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                if (a == null || listener == null || Math.abs(vy) < Math.abs(vx) * 1.5f) return false;
                if (vy < -Ui.dp(getContext(), 600)) listener.onSwipeUp();
                else if (vy > Ui.dp(getContext(), 600)) listener.onSwipeDown();
                return true;
            }
        });
    }

    void setListener(Listener l) {
        listener = l;
    }

    void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
        requestLayout();
    }

    // ---- geometry ---------------------------------------------------------------------------------------

    float cellW() {
        return (getWidth() - 2 * pad) / Item.COLS;
    }

    float cellH() {
        return (getHeight() - insetTop - insetBottom - dockHeight - 2 * pad) / Item.ROWS;
    }

    private float dockTop() {
        return getHeight() - insetBottom - dockHeight;
    }

    RectF rect(Item i) {
        float l = pad + i.x * cellW();
        if (i.inDock()) return new RectF(l, dockTop(), l + cellW(), dockTop() + dockHeight);
        float t = insetTop + pad + i.y * cellH();
        return new RectF(l, t, l + i.w * cellW(), t + i.h * cellH());
    }

    @Override
    protected void onMeasure(int ws, int hs) {
        setMeasuredDimension(MeasureSpec.getSize(ws), MeasureSpec.getSize(hs));
        for (int k = 0; k < getChildCount(); k++) {
            View v = getChildAt(k);
            RectF r = rect((Item) v.getTag());
            int inset = isWidget(v) ? (int) Ui.dp(getContext(), 6) : 0;
            v.measure(MeasureSpec.makeMeasureSpec((int) r.width() - 2 * inset, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec((int) r.height() - 2 * inset, MeasureSpec.EXACTLY));
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int k = 0; k < getChildCount(); k++) {
            View v = getChildAt(k);
            RectF rr = rect((Item) v.getTag());
            int inset = isWidget(v) ? (int) Ui.dp(getContext(), 6) : 0;
            v.layout((int) rr.left + inset, (int) rr.top + inset, (int) rr.right - inset, (int) rr.bottom - inset);
        }
    }

    private static boolean isWidget(View v) {
        return !((Item) v.getTag()).isApp();
    }

    View childAt(float x, float y) {
        for (int k = getChildCount() - 1; k >= 0; k--) {
            View v = getChildAt(k);
            if (x >= v.getLeft() && x < v.getRight() && y >= v.getTop() && y < v.getBottom()) return v;
        }
        return null;
    }

    boolean free(Item self, int x, int y, int w, int h) {
        if (x < 0 || x + w > Item.COLS) return false;
        if (y == Item.DOCK) {
            if (w != 1 || h != 1) return false;
        } else if (y < 0 || y + h > Item.ROWS) {
            return false;
        }
        for (int k = 0; k < getChildCount(); k++) {
            Item o = (Item) getChildAt(k).getTag();
            if (o != self && o.overlaps(x, y, w, h)) return false;
        }
        return true;
    }

    /** The first free w x h spot, top to bottom, right to left (Arabic reading order). */
    int[] freeSpot(int w, int h) {
        for (int y = 0; y + h <= Item.ROWS; y++) {
            for (int x = Item.COLS - w; x >= 0; x--) if (free(null, x, y, w, h)) return new int[]{x, y};
        }
        return null;
    }

    /** Re-lays out with every moved child gliding to its new place. */
    void animateLayout() {
        TransitionManager.beginDelayedTransition(this, new ChangeBounds().setDuration(220));
        requestLayout();
    }

    // ---- touches ----------------------------------------------------------------------------------------

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        gestures.onTouchEvent(e);   // watch swipes over the icons too, without taking their taps
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        gestures.onTouchEvent(e);
        return true;
    }

    // ---- drag and drop ----------------------------------------------------------------------------------

    private int[] target(Item dragged, float x, float y) {
        if (y >= dockTop()) {
            return new int[]{(int) Math.max(0, Math.min(Item.COLS - 1, (x - pad) / cellW())), Item.DOCK};
        }
        // The finger holds the item by its middle.
        int cx = Math.round((x - pad) / cellW() - dragged.w / 2f);
        int cy = Math.round((y - insetTop - pad) / cellH() - dragged.h / 2f);
        return new int[]{Math.max(0, Math.min(Item.COLS - dragged.w, cx)), Math.max(0, Math.min(Item.ROWS - dragged.h, cy))};
    }

    private View viewOf(Item i) {
        for (int k = 0; k < getChildCount(); k++) if (getChildAt(k).getTag() == i) return getChildAt(k);
        return null;
    }

    @Override
    public boolean onDragEvent(DragEvent e) {
        if (!(e.getLocalState() instanceof Item)) return false;
        Item item = (Item) e.getLocalState();
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                dragStartX = -1;
                return true;
            case DragEvent.ACTION_DRAG_LOCATION: {
                if (dragStartX < 0) {
                    dragStartX = e.getX();
                    dragStartY = e.getY();
                }
                if (listener != null) listener.onDragMoved((float) Math.hypot(e.getX() - dragStartX, e.getY() - dragStartY));
                int[] t = target(item, e.getX(), e.getY());
                boolean dock = t[1] == Item.DOCK;
                Item probe = new Item(item.type, "", 0, t[0], t[1], dock ? 1 : item.w, dock ? 1 : item.h);
                hoverRect = rect(probe);
                hoverOk = free(item, t[0], t[1], probe.w, probe.h) || swapTarget(item, t) != null;
                invalidate();
                return true;
            }
            case DragEvent.ACTION_DROP: {
                int[] t = target(item, e.getX(), e.getY());
                boolean dock = t[1] == Item.DOCK;
                if (dock && !item.isApp()) return false;
                if (free(item, t[0], t[1], item.w, item.h)) {
                    item.x = t[0];
                    item.y = t[1];
                } else {
                    Item other = swapTarget(item, t);
                    if (other == null) return false;
                    other.x = item.x;
                    other.y = item.y;
                    item.x = t[0];
                    item.y = t[1];
                }
                animateLayout();
                if (listener != null) listener.onLayoutChanged();
                return true;
            }
            case DragEvent.ACTION_DRAG_ENDED: {
                hoverRect = null;
                invalidate();
                View v = viewOf(item);
                if (v != null) v.setVisibility(VISIBLE);
                return true;
            }
            default:
                return true;
        }
    }

    /** Dropping one app on another single app swaps them. */
    private Item swapTarget(Item dragged, int[] t) {
        if (!dragged.isApp()) return null;
        for (int k = 0; k < getChildCount(); k++) {
            Item o = (Item) getChildAt(k).getTag();
            if (o != dragged && o.isApp() && o.x == t[0] && o.y == t[1]) return o;
        }
        return null;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (hoverRect == null) return;
        // Where the item will land: gold if it fits, faint red if not.
        hover.setStyle(Paint.Style.FILL);
        hover.setColor(hoverOk ? 0x33E9C46A : 0x22FF5A5A);
        float r = Ui.dp(getContext(), 18), in = Ui.dp(getContext(), 4);
        RectF box = new RectF(hoverRect.left + in, hoverRect.top + in, hoverRect.right - in, hoverRect.bottom - in);
        canvas.drawRoundRect(box, r, r, hover);
        hover.setStyle(Paint.Style.STROKE);
        hover.setStrokeWidth(Ui.dp(getContext(), 2));
        hover.setColor(hoverOk ? Ui.GOLD : 0x88FF5A5A);
        canvas.drawRoundRect(box, r, r, hover);
    }
}
