package com.idiken.phonehome;

import android.app.Activity;
import android.app.role.RoleManager;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.UserHandle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * The phone's home screen. Hold an icon or widget to move it (drag), resize or remove it; hold empty space
 * for the home menu (widgets, wallpaper, prayer city, default launcher); swipe up for every app.
 */
public final class MainActivity extends Activity implements HomeGrid.Listener {
    private static final int REQ_BIND = 1, REQ_CONFIGURE = 2, REQ_HOME = 3;
    private static final long MINUTE = 60_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private Views.Wallpaper wallpaper;
    private HomeGrid grid;
    private Views.Host host;
    private AppWidgetManager widgets;
    private List<LauncherActivityInfo> apps = new ArrayList<>();
    private final List<Item> items = new ArrayList<>();
    private Sheets.Layer layer;
    private int insetTop, insetBottom, pendingWidget = -1;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            for (int k = 0; k < grid.getChildCount(); k++) {
                View v = grid.getChildAt(k);
                if (v instanceof Views.Minute) ((Views.Minute) v).onMinute();
            }
            wallpaper.update();
            handler.postDelayed(this, MINUTE - System.currentTimeMillis() % MINUTE + 50);
        }
    };

    private final LauncherApps.Callback appsChanged = new LauncherApps.Callback() {
        @Override public void onPackageRemoved(String p, UserHandle u) { reload(); }
        @Override public void onPackageAdded(String p, UserHandle u) { reload(); }
        @Override public void onPackageChanged(String p, UserHandle u) { reload(); }
        @Override public void onPackagesAvailable(String[] p, UserHandle u, boolean r) { reload(); }
        @Override public void onPackagesUnavailable(String[] p, UserHandle u, boolean r) { reload(); }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        // Draw behind the status and navigation bars; the grid keeps clear of them with insets.
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        w.setStatusBarColor(0);
        w.setNavigationBarColor(0);
        root = new FrameLayout(this);
        wallpaper = new Views.Wallpaper(this);
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));
        grid = new HomeGrid(this);
        grid.setListener(this);
        root.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            insetTop = insets.getSystemWindowInsetTop();
            insetBottom = insets.getSystemWindowInsetBottom();
            grid.setInsets(insetTop, insetBottom);
            return insets;
        });
        setContentView(root);
        widgets = AppWidgetManager.getInstance(this);
        host = new Views.Host(this);
        Ui.launcherApps(this).registerCallback(appsChanged, handler);
        reload();
    }

    @Override
    protected void onDestroy() {
        Ui.launcherApps(this).unregisterCallback(appsChanged);
        super.onDestroy();
    }

    @Override
    protected void onStart() {
        super.onStart();
        host.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            host.stopListening();
        } catch (RuntimeException ignored) {
            // the system may already have dropped the host
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        wallpaper.update();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(tick);
        closeLayer();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        closeLayer();   // Home while a menu or the drawer is open: back to the clean home screen
    }

    @Override
    public void onBackPressed() {
        closeLayer();   // a launcher never leaves on Back
    }

    private void closeLayer() {
        if (layer != null && layer.isOpen()) layer.close();
    }

    // ---- building the home screen -----------------------------------------------------------------------

    private void reload() {
        apps = Ui.apps(this);
        items.clear();
        items.addAll(Store.load(this, apps));
        grid.removeAllViews();
        for (Item i : new ArrayList<>(items)) {
            View v = viewFor(i);
            if (v == null) {
                items.remove(i);
                continue;
            }
            grid.addView(v);
        }
        if (!Store.prefs(this).contains(Store.LAYOUT)) Store.save(this, items);
    }

    private View viewFor(Item i) {
        View v;
        switch (i.type) {
            case Item.APP: {
                LauncherActivityInfo info = Ui.find(this, i.component);
                if (info == null) return null;
                v = Views.icon(this, info, !i.inDock());
                v.setOnClickListener(x -> Ui.launch(this, i.component, x));
                break;
            }
            case Item.CLOCK:
                v = new Views.Clock(this);
                break;
            case Item.PRAYER:
                v = new Views.Prayer(this, i);
                v.setOnClickListener(x -> pickCity());
                break;
            case Item.WIDGET: {
                AppWidgetProviderInfo info = widgets.getAppWidgetInfo(i.widgetId);
                if (info == null) return null;
                AppWidgetHostView hv = host.createView(getApplicationContext(), i.widgetId, info);
                hv.setAppWidget(i.widgetId, info);
                v = hv;
                break;
            }
            default:
                return null;
        }
        v.setTag(i);
        v.setOnLongClickListener(x -> {
            itemMenu(x);
            return true;
        });
        return v;
    }

    @Override
    public void onLayoutChanged() {
        Store.save(this, items);
    }

    // ---- item menu and drag -----------------------------------------------------------------------------

    private RectF screenRect(View v) {
        int[] at = new int[2];
        v.getLocationInWindow(at);
        return new RectF(at[0], at[1], at[0] + v.getWidth(), at[1] + v.getHeight());
    }

    /** Long press: the menu opens and the item lifts; moving the finger drags it and closes the menu. */
    private void itemMenu(View v) {
        Item i = (Item) v.getTag();
        List<Sheets.Row> rows = new ArrayList<>();
        if (!i.isApp()) rows.add(new Sheets.Row(R.drawable.ic_resize, "تغيير الحجم", () -> pickSize(v)));
        if (Item.PRAYER.equals(i.type)) rows.add(new Sheets.Row(R.drawable.ic_place, "مدينة الصلاة", this::pickCity));
        rows.add(new Sheets.Row(R.drawable.ic_delete, "إزالة من الواجهة", () -> remove(v)));
        if (i.isApp()) {
            String pkg = ComponentName.unflattenFromString(i.component).getPackageName();
            rows.add(new Sheets.Row(R.drawable.ic_info, "معلومات التطبيق", () -> appInfo(pkg)));
            rows.add(new Sheets.Row(R.drawable.ic_refresh, "إلغاء التثبيت", () -> uninstall(pkg)));
        }
        String title = i.isApp() ? String.valueOf(Ui.find(this, i.component).getLabel()) : null;
        layer = Sheets.menu(root, title, rows, screenRect(v));
        v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        v.startDragAndDrop(ClipData.newPlainText("", ""), new View.DragShadowBuilder(v), i, 0);
        v.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onDragMoved(float distance) {
        if (distance > Ui.dp(this, 24)) closeLayer();
    }

    private void remove(View v) {
        Item i = (Item) v.getTag();
        if (Item.WIDGET.equals(i.type)) host.deleteAppWidgetId(i.widgetId);
        items.remove(i);
        v.animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(160).withEndAction(() -> {
            grid.removeView(v);
            grid.animateLayout();
        }).start();
        onLayoutChanged();
    }

    private void pickSize(View v) {
        Item i = (Item) v.getTag();
        int[][] sizes = {{2, 1}, {2, 2}, {3, 2}, {4, 1}, {4, 2}, {4, 3}, {4, 4}};
        List<Sheets.Row> rows = new ArrayList<>();
        for (int[] s : sizes) {
            if (!grid.free(i, Math.min(i.x, Item.COLS - s[0]), i.y, s[0], s[1])) continue;
            String mark = s[0] == i.w && s[1] == i.h ? "  ✓" : "";
            rows.add(new Sheets.Row(0, s[0] + " × " + s[1] + mark, () -> {
                i.x = Math.min(i.x, Item.COLS - s[0]);
                i.w = s[0];
                i.h = s[1];
                if (v instanceof Views.Minute) ((Views.Minute) v).onMinute();
                grid.animateLayout();
                onLayoutChanged();
            }));
        }
        layer = Sheets.menu(root, "الحجم (عرض × ارتفاع)", rows, screenRect(v));
    }

    // ---- empty space, gestures --------------------------------------------------------------------------

    @Override
    public void onEmptyLongPress(float x, float y) {
        List<Sheets.Row> rows = new ArrayList<>();
        rows.add(new Sheets.Row(R.drawable.ic_widgets, "إضافة ويدجت", this::pickWidget));
        rows.add(new Sheets.Row(R.drawable.ic_image, "الخلفية", this::pickWallpaper));
        rows.add(new Sheets.Row(R.drawable.ic_place, "مدينة الصلاة", this::pickCity));
        if (!isDefaultHome()) rows.add(new Sheets.Row(R.drawable.ic_check, "اجعلها الواجهة الرئيسية", this::askDefaultHome));
        rows.add(new Sheets.Row(R.drawable.ic_settings, "إعدادات الهاتف", () -> open(new Intent(Settings.ACTION_SETTINGS))));
        rows.add(new Sheets.Row(R.drawable.ic_refresh, "إرجاع الترتيب الافتراضي", () -> {
            for (Item i : items) if (Item.WIDGET.equals(i.type)) host.deleteAppWidgetId(i.widgetId);
            Store.prefs(this).edit().remove(Store.LAYOUT).apply();
            reload();
        }));
        layer = Sheets.menu(root, null, rows, new RectF(x - 1, y - 1, x + 1, y + 1));
        grid.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
    }

    @Override
    public void onSwipeUp() {
        openDrawer();
    }

    /** Swipe down pulls the notification shade, as on most launchers. */
    @Override
    @SuppressWarnings("JavaReflectionMemberAccess")
    public void onSwipeDown() {
        try {
            Object sb = getSystemService("statusbar");
            sb.getClass().getMethod("expandNotificationsPanel").invoke(sb);
        } catch (Exception ignored) {
            // not available on this firmware
        }
    }

    private void openDrawer() {
        layer = Sheets.drawer(root, apps, insetTop, a -> {
            closeLayer();
            Ui.launch(this, a.getComponentName().flattenToString(), null);
        }, a -> {
            String comp = a.getComponentName().flattenToString();
            List<Sheets.Row> rows = new ArrayList<>();
            boolean onHome = false;
            for (Item i : items) if (i.isApp() && i.component.equals(comp)) onHome = true;
            if (!onHome) rows.add(new Sheets.Row(R.drawable.ic_add, "إضافة إلى الواجهة", () -> {
                closeLayer();
                addApp(comp);
            }));
            rows.add(new Sheets.Row(R.drawable.ic_info, "معلومات التطبيق", () -> appInfo(a.getComponentName().getPackageName())));
            rows.add(new Sheets.Row(R.drawable.ic_refresh, "إلغاء التثبيت", () -> uninstall(a.getComponentName().getPackageName())));
            Sheets.menu(root, String.valueOf(a.getLabel()), rows, null);
        });
    }

    private void addApp(String comp) {
        int[] spot = grid.freeSpot(1, 1);
        if (spot == null) {
            toast("لا توجد خانة فارغة في الواجهة");
            return;
        }
        add(Item.app(comp, spot[0], spot[1]));
    }

    private void add(Item i) {
        items.add(i);
        View v = viewFor(i);
        if (v == null) {
            items.remove(i);
            return;
        }
        v.setAlpha(0f);
        v.setScaleX(0.8f);
        v.setScaleY(0.8f);
        grid.addView(v);
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        onLayoutChanged();
    }

    // ---- widgets ----------------------------------------------------------------------------------------

    private void pickWidget() {
        layer = Sheets.widgets(root, insetTop, type -> {
            int[] spot = grid.freeSpot(4, Item.CLOCK.equals(type) ? 2 : 1);
            if (spot == null) {
                toast("لا توجد مساحة فارغة لهذه الويدجت");
                return;
            }
            add(new Item(type, "", 0, spot[0], spot[1], 4, Item.CLOCK.equals(type) ? 2 : 1));
        }, this::bindWidget);
    }

    /** Android widgets need the owner's OK once per app (the system bind dialog), then maybe a setup screen. */
    private void bindWidget(AppWidgetProviderInfo info) {
        int id = host.allocateAppWidgetId();
        if (widgets.bindAppWidgetIdIfAllowed(id, info.getProfile(), info.provider, null)) {
            configureOrPlace(id);
        } else {
            pendingWidget = id;
            Intent i = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER_PROFILE, info.getProfile());
            startActivityForResult(i, REQ_BIND);
        }
    }

    private void configureOrPlace(int id) {
        AppWidgetProviderInfo info = widgets.getAppWidgetInfo(id);
        if (info == null) {
            host.deleteAppWidgetId(id);
            return;
        }
        if (info.configure != null) {
            pendingWidget = id;
            try {
                host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIGURE, null);
                return;
            } catch (Exception e) {
                // some widgets declare a setup screen they don't export: place them as they are
            }
        }
        placeWidget(id);
    }

    private void placeWidget(int id) {
        AppWidgetProviderInfo info = widgets.getAppWidgetInfo(id);
        float cw = Math.max(1, grid.cellW()), ch = Math.max(1, grid.cellH());
        int w = Math.max(1, Math.min(Item.COLS, (int) Math.ceil(info.minWidth / cw)));
        int h = Math.max(1, Math.min(4, (int) Math.ceil(info.minHeight / ch)));
        int[] spot = grid.freeSpot(w, h);
        if (spot == null) {
            // Not enough room at its natural size: take the largest free area it may shrink to.
            int minW = Math.max(1, (int) Math.ceil(Math.min(info.minWidth, info.minResizeWidth > 0 ? info.minResizeWidth : info.minWidth) / cw));
            int minH = Math.max(1, (int) Math.ceil(Math.min(info.minHeight, info.minResizeHeight > 0 ? info.minResizeHeight : info.minHeight) / ch));
            for (int area = w * h; area >= 1 && spot == null; area--) {
                for (int tw = Math.min(Item.COLS, w); tw >= minW && spot == null; tw--) {
                    int th = area / tw;
                    if (th * tw != area || th > h || th < minH) continue;
                    spot = grid.freeSpot(tw, th);
                    if (spot != null) {
                        w = tw;
                        h = th;
                    }
                }
            }
        }
        if (spot == null) {
            host.deleteAppWidgetId(id);
            toast("لا توجد مساحة فارغة لهذه الويدجت");
            return;
        }
        add(new Item(Item.WIDGET, info.provider.flattenToString(), id, spot[0], spot[1], w, h));
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_BIND || request == REQ_CONFIGURE) {
            int id = pendingWidget;
            pendingWidget = -1;
            if (id < 0) return;
            if (result != RESULT_OK) {
                host.deleteAppWidgetId(id);
            } else if (request == REQ_BIND) {
                configureOrPlace(id);
            } else {
                placeWidget(id);
            }
        }
    }

    // ---- settings ---------------------------------------------------------------------------------------

    private void pickCity() {
        List<Sheets.Row> rows = new ArrayList<>();
        String current = Store.city(this);
        for (PrayerTimes.City c : PrayerTimes.CITIES) {
            rows.add(new Sheets.Row(c.name.equals(current) ? R.drawable.ic_check : 0, c.arabic, () -> {
                Store.prefs(this).edit().putString(Store.CITY, c.name).apply();
                handler.removeCallbacks(tick);
                handler.post(tick);
            }));
        }
        layer = Sheets.menu(root, "مدينة الصلاة", rows, null);
    }

    private void pickWallpaper() {
        String now = Store.prefs(this).getString(Store.WALLPAPER, Store.NATURE);
        List<Sheets.Row> rows = new ArrayList<>();
        rows.add(new Sheets.Row(Store.NATURE.equals(now) ? R.drawable.ic_check : 0, "طبيعة تتغيّر حسب الوقت", () -> setWallpaper(Store.NATURE)));
        rows.add(new Sheets.Row(Store.SYSTEM.equals(now) ? R.drawable.ic_check : 0, "خلفية الهاتف", () -> setWallpaper(Store.SYSTEM)));
        rows.add(new Sheets.Row(R.drawable.ic_image, "اختيار خلفية جديدة للهاتف…", () -> {
            setWallpaper(Store.SYSTEM);
            open(Intent.createChooser(new Intent(Intent.ACTION_SET_WALLPAPER), "الخلفية"));
        }));
        layer = Sheets.menu(root, "الخلفية", rows, null);
    }

    private void setWallpaper(String which) {
        Store.prefs(this).edit().putString(Store.WALLPAPER, which).apply();
        wallpaper.update();
    }

    private boolean isDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            return rm != null && rm.isRoleHeld(RoleManager.ROLE_HOME);
        }
        android.content.pm.ResolveInfo r = getPackageManager().resolveActivity(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0);
        return r != null && getPackageName().equals(r.activityInfo.packageName);
    }

    /** Android 10+ asks with its own dialog; older phones open the default-apps screen. */
    private void askDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_HOME);
                return;
            }
        }
        open(new Intent(Settings.ACTION_HOME_SETTINGS));
    }

    private void appInfo(String pkg) {
        open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
    }

    private void uninstall(String pkg) {
        open(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)));
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("غير متاح على هذا الهاتف");
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
